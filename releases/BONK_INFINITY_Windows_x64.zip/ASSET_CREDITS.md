# MEGACLONK asset credits

- **Jacob – Game Ready OC v1.00**, Jupifox: https://jupifox.itch.io/jacob-game-ready-character.
  CC BY4.0: https://creativecommons.org/licenses/by/4.0/. Supplied Jacob.zip;
  assets/vendor/jacob. Changes: demo props/sword hidden, atlas references rebound,
  original additive movement/glide/hit/death poses over supplied Idle. NPCs reuse this model.
- **Kurland**, GGBotNet: https://ggbot.itch.io/kurland-font. SIL OFL1.1,
  Reserved Font Name Kurland. Unmodified regular TTF in assets/fonts; full licence retained.
- **Buffs and Ability Icons demo**, GandalfHardcore:
  https://gandalfhardcore.itch.io/buffs-and-ability-icons-pixel-art-pack.
  Contained terms permit free/commercial game use and editing, prohibit standalone
  resale/redistribution. Five supplied icons reused across eight abilities. Gold frames are original.
- **Undead Skill / Undead Loot Pixel Art Icons**, Free Game Assets / CraftPix:
  https://free-game-assets.itch.io/free-undead-skill-pixel-art-icons,
  https://free-game-assets.itch.io/free-undead-loot-pixel-art-icons.
  CraftPix free-asset terms: https://craftpix.net/file-licenses/; text supplied by user.
  Game use/modification/distribution permitted. No artwork-export feature or standalone
  asset product. Weapon/item icons selected from supplied packs; included loot scrolls
  also serve as tome icons. Paths assets/vendor/weapons and assets/vendor/items.
- **Lowpoly Environment Pack**, k0rveen: https://k0rveen.itch.io/lowpoly-environment-pack.
  Publisher metadata specifies CC BY4.0: https://creativecommons.org/licenses/by/4.0/.
  assets/vendor/environment; meshes recentered/resized and batched, with simplified collisions.
- **200+ Free RPG Sounds**, Clutch Assets: https://clutch-assets.itch.io/200-free-rpg-sounds.
  Publisher permits commercial/non-commercial project use; no claiming authorship or
  reselling the sounds. assets/vendor/audio; filenames normalized, selected clips wired
  to gameplay and ambient audio. Original-name manifest retained. Not labelled CC0.
- **Ancient Reliques**, user-supplied Ancient Reliques.zip. Creator/URL not identified
  inside archive; user confirms permission for personal game use. assets/vendor/relics;
  head-totem landmark resized and batched. No unrelated licence is attributed.
- **Electric FX Free**, Binbun3D / bun3d.com. Included licence: CC0,
  https://creativecommons.org/publicdomain/zero/1.0/. assets/vendor/electric.
  Adapted zap shader clamps its vertex mask before square root; custom bounded GPU emitter.
- **PSX FX Free by heyheythere - https://heyheythere.itch.io/psx-fx-free - CC BY 4.0**
  https://creativecommons.org/licenses/by/4.0/. assets/vendor/psx_fx; supplied sheets/metadata
  used by a custom cached, pooled flipbook player, scaled for combat. Full licence retained.
- **Pixelated Elegance**, GGBotNet, https://github.com/ggbotnet/fonts-cc0, CC0.
  Retained fallback font; assets/fonts/LICENSE-CC0.txt.

Original project code, procedural enemy/boss geometry/poses, terrain generation,
shaders, weapon geometry and supplemental effects were created for MEGACLONK.
The Quaternius Bestiary and paid 48 Scroll packs are not integrated; see docs/ASSET_ACCESS.md.
Godot engine notices are bundled separately in GODOT_COPYRIGHT.txt.
