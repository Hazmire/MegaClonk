@echo off
cd /d "%~dp0"
start "" "BONK_INFINITY.exe" --rendering-method gl_compatibility
