# PSX Sea Horror Monsters - catalog

| monster | kind | tris | bones | height | skins | clips |
|---|---|---|---|---|---|---|
| Drowned Fisherman (`drowned`) | humanoid | 1,690 | 29 | 1.78 m | oilskin, deckhand | Idle 3.60 s loop, Walk 2.00 s loop, Run 0.90 s loop, Attack 1.30 s, Attack2 1.60 s, Hit 0.60 s, Death 2.40 s, Retch 2.80 s |
| Giant Crab (`crab`) | beast | 2,206 | 38 | 0.71 m | rust, bone | Idle 4.00 s loop, Walk 0.80 s loop, Run 0.40 s loop, Attack 1.30 s, Attack2 1.60 s, Hit 0.50 s, Death 2.40 s, Threat 2.40 s |

**Drowned Fisherman** (drowned): Bloated drowned fisherman in a torn oilskin coat and sou'wester, dragging one boot; clubs, grabs and bites, and retches up seawater.

- Skins: oilskin: yellow oilskin coat and sou'wester, oatmeal cable-knit sweater, black boots; deckhand: dark green oilskin, navy rib-knit sweater, dirty white boots
- Game data: walk 0.33 m/s, run 1.69 m/s; Attack range 1.3 m, the blow lands at 0.56 s; Attack2 range 0.95 m, lands at 0.84 s; height 1.78 m, body radius 0.34 m

**Giant Crab** (crab): Huge barnacle-crusted harbor crab with a spiky shell, glowing eyes on stalks and one oversized crusher claw: scuttles forward, pinches, slams the crusher down and rears up with both claws raised.

- Skins: rust: red-brown shell crusted with gray-white barnacles, black-tipped claws, ember eyes; bone: pale abyssal white shell with pale crusted barnacles, dark violet claw tips, cyan eyes
- Game data: walk 0.62 m/s, run 2.55 m/s; Attack range 1.5 m, the blow lands at 0.56 s; Attack2 range 1.5 m, lands at 0.66 s; height 0.71 m, body radius 0.6 m

