# PSX Sea Horror Monsters - Free Sampler - Godot 4.3 project

bitkiln - https://bitkiln.itch.io

2 monsters of PSX Sea Horror Monsters, set up exactly like in the full pack: a scene with collision, the
model, all of its clips and the enemy behavior script. The full pack has 13 monsters.

Open `project.godot` with Godot 4.3 or newer and press F5: the monster showcase starts.
The hunt demo is `demo/hunt.tscn` (open it and press F6). Both run on the Compatibility renderer, so they work on
almost any GPU; the PSX shaders work in Forward+ and Mobile too.

## Showcase (demo/showcase.tscn)

At the start every monster plays all of its clips one after the other; its label shows the clip and the skin. The
room is a round ship's hold on a dark steel deck plate (the `deck_steel_green` texture), built with GridMaps of the
PSX Sea Horror Modular Kit sampler: ceiling with lamps and a hull wall.

| key | action |
|---|---|
| C | every monster plays all of its clips in turn |
| 1 2 3 4 5 6 | Idle, Walk, Run, Attack, Hit, Death on every monster |
| 7 8 9 | the extra clips (Attack2, Scream...); a monster without one stands idle |
| K | next skin |
| P | PSX shader on / off |
| R | turntable |
| Space | pause the clips |
| [ ] | slower / faster |
| Tab / Shift+Tab | the next / previous monster alone, the camera swings around it (mouse wheel: closer / farther) |
| O | every monster again, the camera looks along the stage |
| W A S D, mouse | fly (click into the window to capture the mouse) |
| Q / E, Shift | down / up, faster |
| L, H, Esc | name labels, help, free the mouse |

One-shot clips repeat after a short pause, so you can watch them as often as you like.

## Hunt (demo/hunt.tscn)

The aft corridors of the trawler SG-117 (crew cabin, flooded corridors and a small fish
hold): 36 cells of 2 x 2 m painted with 7 GridMaps of the PSX Sea Horror Modular Kit.
2 monsters stroll, patrol or wait in it. They notice you when you come into view, follow you around the
walls and attack. Shoot them. You start in the crew cabin; keep the flashlight on.
You walk at 1.8 m/s: sprint to get away.

A sprint (5 m/s) lasts 4 s on a full stamina bar (SPRINT, right of your health). The bar refills in 5 s, starting
half a second after you stop sprinting; once it has run empty you can sprint again when it is back to a quarter
(`sprint_time` and `stamina_refill_time` in `scripts/player.gd`).

| key | action |
|---|---|
| W A S D / arrows, mouse | walk, look around (click into the window first) |
| Shift, Space | sprint, jump |
| F | flashlight |
| left mouse button | shoot |
| P | PSX effects on / off |
| G | god mode (the monsters cannot hurt you) |
| N | every monster hunts you, from wherever it is in the level |
| R | restart |
| H, Esc | help, free the mouse |

When your health reaches 0 the scene starts again.

## Using a monster in your own project

1. Copy `monsters/`, `scripts/` and `shaders/` into your project. Copy the `[importer_defaults]` block of this
   `project.godot` into yours **before** the files are imported, so the textures stay sharp and lossless
   (GLB: Embedded Image Handling = Embed as Uncompressed; PNG: Lossless, Detect 3D off). Already imported? Select
   the files, change it in the Import dock and click Reimport.
2. Drag `monsters/<name>/<name>.tscn` into your level. That is a complete enemy: CharacterBody3D, collision
   capsule, the model, a NavigationAgent3D and `scripts/monster_brain.gd`, set up for that monster (speeds that
   match its clips, attack range and the moment the blow lands, skins, alert and idle clips).
3. Put your player into the group `player` and give it a `take_damage(amount: float, from_position: Vector3)`
   method (and `is_dead() -> bool` if it can die). That is all the monsters need.
4. Add a NavigationRegion3D with a baked navigation mesh to your level and the monsters follow paths around walls.
   Without one they walk straight at their goal and slide along whatever is in the way.

In code:

```gdscript
var monster := preload("res://monsters/drowned/drowned.tscn").instantiate() as MonsterBrain
monster.skin = "deckhand"
add_child(monster)
monster.global_position = Vector3(4.0, 0.0, -6.0)
monster.died.connect(func(): print(monster.monster_name, " is down"))
# your bullets / weapons:
monster.take_damage(25.0, global_position)
```

The GLB files work on their own, too: `monsters/<name>/<name>_<skin>.glb` is a Node3D with
`Armature/Skeleton3D/<mesh>` and an AnimationPlayer with every clip. Godot imports every clip as play-once; the
brain turns on looping for the looping clips when the monster starts. Using a GLB without the brain, set the loop
mode yourself (Advanced Import Settings > Animation > Loop Mode, or `anim.loop_mode = Animation.LOOP_LINEAR`).

Units and directions: meters, +Y up, the origin is on the floor and the models face +Z (the glTF convention). The
clips play in place: the brain (or your code) moves the body. When you turn a monster yourself, use
`look_at(target, Vector3.UP, true)` so +Z faces the target.

## Together with PSX Horror Monsters

Both packs have `scripts/monster_brain.gd` (class `MonsterBrain`), `scripts/player.gd` and `shaders/` at the same
paths. In a project with both, keep the files of this pack (the header of `monster_brain.gd` says "Version 2"):
this brain does everything the one of PSX Horror Monsters does and runs that pack's monster scenes as they are; its
player also hits the hitboxes of long monsters (and walks at 1.8 m/s instead of 2.8, with a stamina bar for the
sprint), and the shaders differ only in their comments. The older brain lacks options that the sea monsters use
(`stationary`, `turn_limit`, `patrol_points`, the glow and lantern options and more), so do not copy its `scripts/`
over these. The monsters of PSX Horror Monsters then get the new flinch rules, too, and with Avoidance Enabled on
their NavigationAgent3D they steer around the others.

Copy only the `monsters/` folder of PSX Horror Monsters into this project: its `demo/` folder, `project.godot`,
`icon.png` and README use the same file names as this project's, so copying one whole project into the other mixes
up the two demos and replaces the project settings.

## MonsterBrain (scripts/monster_brain.gd)

States: IDLE (stands, sometimes plays an idle variation; a dormant monster waits frozen until it is woken),
WANDER (strolls around its start point, or walks to its next patrol point), CHASE (runs at the target; plays the
alert clip once when it spots it), ATTACK (Attack or Attack2, chosen at random when both reach; a walking monster
whose Attack2 reaches less far than its Attack steps in closer for it with `attack2_chance`, unless other monsters
stand around the target; the blow lands at `attack_hit_time` if the target is still in reach and in front), HIT (after damage; it interrupts an attack unless
the blow is about to land, see Flinching below), DEAD (Death clip, no more collision with players, monsters and
bullets, the body stays on the floor).

| group | options |
|---|---|
| (top) | `monster_name`, `active` (off: the monster stands still and ignores everything) |
| Target | `target_group` ("player"), `detect_range`, `lose_range`, `need_line_of_sight`, `sight_mask`, `eye_height`, `eye_forward`, `forget_time` |
| Movement | `walk_speed`, `run_speed`, `use_run`, `acceleration`, `turn_speed`, `turn_limit`, `stationary`, `gravity`, `walk_animation_speed` / `run_animation_speed` (the clips speed up or slow down to match a changed speed, so the feet do not slide) |
| Wander | `wander`, `wander_radius`, `idle_time`, `patrol_points` |
| Attack | `attack_range`, `attack_hit_time`, `attack2_range`, `attack2_hit_time`, `attack2_second_hit_time` (a second blow in Attack2, 0 = none), `attack2_chance`, `attack_commit_time`, `attack_cooldown`, `damage`, `hit_reach`, `hit_angle` |
| Health | `max_health`, `flinch`, `flinch_cooldown`, `flinch_min_damage`, `remove_after`, `hitbox` |
| Glow | `fade_glow_on_death`, `glow_fade_time`, `carried_light`, `light_colors` |
| Animations | `animation_player`, the clip names (`anim_idle` ... `anim_death`, `anim_attack2`, `anim_alert`), `start_dormant` + `anim_wake`, `wake_every_time`, `anim_stationary`, `anim_retract`, `idle_variations`, `loop_animations`, `blend_time` |
| Skin | `skin_textures`, `skin` |
| Hover | `hover_height`, `hover_bob`, `hover_period`, `model` (for floating models whose clips stand on the floor) |
| Navigation | `use_navigation` |

Signals: `state_changed`, `target_spotted`, `target_lost`, `attack_started`, `attack_landed`, `damaged`, `woke_up`,
`died`.
Methods: `take_damage(amount, from_position, source)`, `kill()`, `revive()`, `hunt(node, forced)`, `is_dead()`,
`is_dormant()`, `is_forced_hunt()`, `play_animation(name, restart, blend)`, `next_skin()`, `skin_names()`,
`state_name()`, `set_glow(amount)`, `fade_glow(amount, seconds)`, `get_glow()`.

**Hunting on command.** `hunt(node)` makes a monster hunt a node at once (it does not need to see it first), for
alarms, triggers and scripted scares. It keeps coming however far away or hidden the node is (`lose_range` and
`forget_time` do not count) until the node dies, or until the monster sees it close by (within `detect_range` and
`lose_range`) or gets within `attack_range` of it; from then on the normal rules apply. `hunt(node, false)` applies
the normal rules at once. The N key of the hunt demo calls `hunt()` on every monster.

**Flinching.** A hit plays Hit and pushes the monster back a little, which interrupts its attack, except in the last
`attack_commit_time` seconds (0.25 s by default) before the blow lands. After a Hit the monster acts for
`flinch_cooldown` seconds (1 s by default) before damage can make it flinch again, and blows weaker than
`flinch_min_damage` never do, so a fast-firing weapon cannot keep a monster from striking back. Getting hit never
makes a monster strike more often, either: an attack that a Hit cuts short after its blow counts to the end of its
clip before `attack_cooldown` starts, and the cooldown keeps running through Hit. Every hit still costs health.

**Crowds.** The monster scenes have Avoidance Enabled on their NavigationAgent3D, so on a navigation mesh the
monsters steer around each other instead of pushing (never faster than they walk or run: the brain sets the agent's
`max_speed`), and a monster that was pushed aside gets a new path every second. Where a corridor is too narrow to
pass, they still wait in line, and when the room around the player is full (four to ten monsters, depending on the
walls), the others wait behind them until a place comes free. Avoidance works on the floor plane and only between
agents that have it on (your player is not avoided).

**Patrols.** Fill `patrol_points` (positions in the space of the monster's parent node) and the monster walks from
point to point instead of strolling at random, standing a moment (`idle_time`) at each one. In the hunt demo the
humanoids in the corridors patrol like that.

**Hitboxes (Giant Crab).** A long or wide body (a tail, legs, fins or arms that reach far out) does not fit into a
collision capsule that can still turn in a corridor, so these monsters move with a capsule around their middle and
carry a `Hitbox` (Area3D on the monster layer) that covers the whole body of the Idle pose. Shots that collide with
areas hit them anywhere: set `collide_with_areas = true` on your raycast query, as `scripts/player.gd` does. The
brain switches the hitbox off on death.

**Glowing parts (Giant Crab).** Glowing eyes, lures, organs, growths and lantern glass are emissive surfaces of the
model: they shine in the dark, but they do not light the level. With `fade_glow_on_death` (on by default) they go out
over `glow_fade_time` seconds (1.5) when the monster dies. Only the dead monster fades: its glowing surfaces get
materials of their own, so other monsters with the same skin keep glowing. `set_glow(amount)` (1 = as made, 0 = dark)
and `fade_glow(amount, seconds)` change it from your code; `revive()` lights it again. The showcase fades it in
Death, too.

Physics layers of the demo: 1 level, 2 player, 3 monsters (a monster collides with 1, 2 and 3). Change them in
the monster scene if your project uses other layers; `sight_mask` is the layer that blocks the monsters' view.

Your own models work too: put the script on a CharacterBody3D with your model as a child and type in the names of
your clips in the Animations group.

## Skins

Every monster has two skins. Pick one in the Inspector (MonsterBrain > Skin) or in code with
`monster.skin = "<name>"` or `monster.next_skin()`. The brain puts the skin texture (`monsters/<name>/*.png`) on
the model, shared by every monster with the same skin, and it keeps working while the PSX shader is on.
Each skin is also a GLB of its own, with that texture inside.

## The PSX shader

`shaders/psx_lit.gdshader`: vertex snapping to a low virtual resolution, affine texture mapping, nearest
sampling without mipmaps, 15-bit color with dithering, diffuse light without highlights. Turn the materials of
any node tree into PSX materials and back:

```gdscript
const PSX := preload("res://shaders/apply_psx.gd")
PSX.apply(self)                               # every material under this node -> PSX shader
PSX.restore(self)                             # back to the original materials
PSX.set_setting("snap_resolution", 480.0)    # change a setting on every PSX material
```

Call `PSX.apply()` on monsters you spawn later, too. Depth fog (Environment > Fog > Mode: Depth) and a dark ambient
light complete the look, as in the hunt demo. The kit's level pieces already use the PSX shader in their own
materials (`materials/ship_*.tres`).

## The monsters

| monster | scene | skins | clips | walk / run m/s | attack range | notes |
|---|---|---|---|---|---|---|
| Drowned Fisherman | `monsters/drowned/drowned.tscn` | oilskin, deckhand | Idle, Walk, Run, Attack, Attack2, Hit, Death, Retch | 0.33 / 1.69 | 1.3 m | idle Retch |
| Giant Crab | `monsters/crab/crab.tscn` | rust, bone | Idle, Walk, Run, Attack, Attack2, Hit, Death, Threat | 0.62 / 2.55 | 1.5 m | body hitbox; alert Threat; idle Threat; glowing parts |

Collision capsules are sized from each monster's measurements (height and body radius). Damage and health in the
scenes are starting values; tune them for your game.

## The demo level

`demo/hunt.tscn` is painted with GridMaps that use `meshlibs/Ship.meshlib`, the Ship MeshLibrary of the free sampler
of the PSX Sea Horror Modular Kit (10 trawler corridor pieces: floor, ceiling, ceiling light, wall, wall with pipes,
porthole wall, watertight door wall, watertight door, web frame, corner post). The GridMaps sit under the
NavigationRegion3D, which bakes its navigation mesh from their collision when the scene starts (with 0.1 m cells:
the project's navigation map uses the same cell size and height, Project Settings > Navigation > 3D). Cell size
(2, 3, 2), Center Y off, one GridMap per layer (floors, walls, details, ceilings), because a GridMap holds one piece
per cell. Select a GridMap and paint more corridors; the full kit's MeshLibrary keeps the same item ids. The flood
water is a plane with `demo/flood_water.gdshader`, the props are GLB files of the PSX Sea Horror Props sampler
(`props/`; the larger ones standing in the rooms have box collisions), the posters, blood and barnacles are textured
quads.

## Folders

| folder | content |
|---|---|
| `monsters/<name>/` | `<name>.tscn` (ready enemy), `<name>_<skin>.glb` (one per skin), `<name>_<skin>.png` (skin textures) |
| `scripts/` | `monster_brain.gd` (enemy behavior), `player.gd` (first-person player of the hunt demo) |
| `shaders/` | the PSX shader (`psx_lit.gdshader`, double-sided version) and `apply_psx.gd` |
| `demo/` | `showcase.tscn`, `hunt.tscn`, the player scene, the flood water shader, camera and light scripts, textures |
| `meshlibs/`, `materials/`, `textures/` | the Ship MeshLibrary of the PSX Sea Horror Modular Kit sampler, its materials and textures |
| `props/` | the 10 props of the PSX Sea Horror Props sampler |

## Credits

The level pieces, props and demo textures come from the free samplers of the PSX Sea Horror Modular Kit, PSX Sea
Horror Props and PSX Sea Horror Texture Pack by bitkiln (https://bitkiln.itch.io), free for personal and commercial
projects.

## Contact

Questions, problems or monster requests: comment on the itch.io page (https://bitkiln.itch.io) or write to
@bitkiln_assets on X. Thank you for supporting a small creator!
