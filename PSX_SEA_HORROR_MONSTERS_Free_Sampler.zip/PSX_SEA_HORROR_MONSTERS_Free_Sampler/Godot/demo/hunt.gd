extends Node3D
## Hunt demo of PSX Sea Horror Monsters (bitkiln - https://bitkiln.itch.io).
##
## The flooded lower deck of the trawler SG-117, painted with GridMaps of the PSX Sea Horror Modular Kit (Ship
## MeshLibrary, free sampler) and dressed with props of the PSX Sea Horror Props sampler. The monsters wander and
## patrol, notice you when you come into view, follow you around the walls (NavigationAgent3D on the navigation mesh
## baked at start) and attack. Shoot them with the left mouse button.
##   P PSX effects on / off    G god mode (monsters cannot hurt you)
##   N every monster hunts you: MonsterBrain.hunt() makes each one come from wherever it is (the Tentacle Lurker
##     cannot leave its wall: it wakes up and waits for you there)
##   R restart                 H help
## The player keys are in scripts/player.gd (WASD, mouse, Shift sprint, F flashlight, Esc frees the mouse).

const PSX := preload("res://shaders/apply_psx.gd")
const HELP := "WASD move   mouse look (click)   Shift sprint   Space jump   F flashlight   left click shoot\n" + \
		"P PSX effects   G god mode   N every monster hunts you   R restart   H help   Esc free the mouse"

## Shown at the top of the screen.
@export var level_name := ""
@export var psx_enabled := true
## Bake the navigation mesh of the Navigation node when the scene starts (the GridMaps and props are its source).
@export var bake_navigation := true

var _monsters: Array[MonsterBrain] = []
var _alive := 0
var _counter: Label
var _help: Label
var _message: Label

@onready var _player := $Player as CharacterBody3D
@onready var _navigation := $Navigation as NavigationRegion3D


func _ready() -> void:
	if bake_navigation and _navigation != null and _navigation.navigation_mesh != null:
		_bake()
	for node in $Monsters.get_children():
		var monster := node as MonsterBrain
		if monster == null:
			continue
		_monsters.append(monster)
		monster.died.connect(_on_monster_died)
	_alive = _monsters.size()
	_build_hud()
	set_psx(psx_enabled)
	_update_hud()


## Bakes the navigation mesh from the collision of the GridMaps and props. A GridMap builds its collision shapes at
## the end of its first frame, so the bake waits for that frame (the monsters walk straight at their goals until the
## navigation mesh is there).
func _bake() -> void:
	await get_tree().process_frame
	_navigation.bake_navigation_mesh(false)


func _build_hud() -> void:
	var hud := CanvasLayer.new()
	hud.name = "HUD"
	add_child(hud)
	_counter = _label(hud, 24, Control.PRESET_TOP_RIGHT)
	_counter.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_counter.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	_help = _label(hud, 15, Control.PRESET_TOP_LEFT)
	_help.text = (level_name + "\n" if level_name != "" else "") + HELP
	_help.offset_top = 52.0
	_help.modulate = Color(1, 1, 1, 0.8)
	_message = _label(hud, 30, Control.PRESET_CENTER)
	_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_message.grow_horizontal = Control.GROW_DIRECTION_BOTH
	_message.grow_vertical = Control.GROW_DIRECTION_BOTH
	_message.position.y += 60.0


func _label(parent: Node, size: int, preset: Control.LayoutPreset) -> Label:
	var label := Label.new()
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", Color(0.92, 0.9, 0.84))
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	label.add_theme_constant_override("outline_size", 6)
	parent.add_child(label)
	label.set_anchors_and_offsets_preset(preset, Control.PRESET_MODE_MINSIZE, 16)
	return label


## Turns the PSX effects on or off for the whole level: the PSX shader on the monsters and props (apply_psx.gd),
## vertex snapping, affine textures and 15-bit color on the kit's materials and the water.
func set_psx(on: bool) -> void:
	psx_enabled = on
	if on:
		PSX.apply(self)
	else:
		PSX.restore(self)
	for m in level_materials():
		if m.shader != null and m.shader.resource_path.ends_with("flood_water.gdshader"):
			m.set_shader_parameter("vertex_snap", on)
			continue
		m.set_shader_parameter("vertex_snap", on)
		m.set_shader_parameter("affine_strength", 1.0 if on else 0.0)
		m.set_shader_parameter("color_15bit", on)
		m.set_shader_parameter("dithering", on)
	_update_hud()


## Every ShaderMaterial of the GridMaps and the water of this level.
func level_materials() -> Array[ShaderMaterial]:
	var found: Array[ShaderMaterial] = []
	for node in find_children("*", "GridMap", true, false):
		var lib := (node as GridMap).mesh_library
		if lib == null:
			continue
		for id in lib.get_item_list():
			_add_mesh_materials(lib.get_item_mesh(id), found)
	for node in find_children("*", "MeshInstance3D", true, false):
		if _in_monster(node):
			continue
		var mi := node as MeshInstance3D
		_add_mesh_materials(mi.mesh, found)
		var m := mi.material_override as ShaderMaterial
		if m != null and not found.has(m) and not mi.has_meta(&"psx_original_material_override"):
			found.append(m)
	return found


func _in_monster(node: Node) -> bool:
	var n := node.get_parent()
	while n != null and n != self:
		if n is MonsterBrain:
			return true
		n = n.get_parent()
	return false


func _add_mesh_materials(mesh: Mesh, found: Array[ShaderMaterial]) -> void:
	if mesh == null:
		return
	for s in mesh.get_surface_count():
		var m := mesh.surface_get_material(s) as ShaderMaterial
		if m != null and not found.has(m):
			found.append(m)


func _unhandled_input(event: InputEvent) -> void:
	var key := event as InputEventKey
	if key == null or not key.pressed or key.echo:
		return
	match key.keycode:
		KEY_P:
			set_psx(not psx_enabled)
		KEY_G:
			if _player != null:
				_player.set("invulnerable", not bool(_player.get("invulnerable")))
		KEY_N:
			hunt_player()
		KEY_R:
			get_tree().reload_current_scene()
			return
		KEY_H:
			_help.visible = not _help.visible
		_:
			return
	_update_hud()
	get_viewport().set_input_as_handled()


## Every living monster hunts the player (the N key). hunt() is a forced hunt: the monsters keep coming however
## far away they are until they see the player close by or reach it.
func hunt_player() -> void:
	if _player == null:
		return
	for monster in _monsters:
		if not monster.is_dead():
			monster.hunt(_player)


func _on_monster_died() -> void:
	_alive = 0
	for monster in _monsters:
		if not monster.is_dead():
			_alive += 1
	_update_hud()
	if _alive == 0:
		_message.text = "Every monster is down.\nPress R to play again."


func _update_hud() -> void:
	if _counter == null:
		return
	var god := _player != null and bool(_player.get("invulnerable"))
	_counter.text = "MONSTERS %d / %d%s\nPSX effects %s" % [_alive, _monsters.size(), "   GOD MODE" if god else "",
			"ON" if psx_enabled else "OFF"]
