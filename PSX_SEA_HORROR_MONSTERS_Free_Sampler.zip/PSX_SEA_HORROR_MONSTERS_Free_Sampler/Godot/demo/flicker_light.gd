extends OmniLight3D
## Light that flickers like a failing bulb (mode 0) or a lantern flame (mode 1).
## (bitkiln - PSX Sea Horror Monsters demo - https://bitkiln.itch.io)

@export_enum("Failing bulb", "Flame") var mode := 0
## Lights with different seeds flicker differently (the same seed always gives the same pattern).
@export var flicker_seed := 1

var _base := 1.0
var _wait := 0.0
var _level := 1.0
var _state := 1


func _ready() -> void:
	_base = light_energy
	_state = absi(flicker_seed) * 7919 + 13


## Next number between 0 and 1 of this light's own sequence.
func _next() -> float:
	_state = (_state * 1103515245 + 12345) % 2147483648
	return float(_state) / 2147483648.0


func _between(a: float, b: float) -> float:
	return a + (b - a) * _next()


func _process(delta: float) -> void:
	if mode == 1:
		_wait -= delta
		if _wait <= 0.0:
			_wait = _between(0.05, 0.12)
			_level = _between(0.78, 1.08)
		light_energy = lerpf(light_energy, _base * _level, 1.0 - exp(-14.0 * delta))
		return
	_wait -= delta
	if _wait > 0.0:
		return
	if _next() < 0.14:
		light_energy = _base * _between(0.04, 0.35)
		_wait = _between(0.03, 0.11)
	else:
		light_energy = _base * _between(0.93, 1.04)
		_wait = _between(0.15, 1.8)
