PSX SEA HORROR MONSTERS - FREE SAMPLER
by bitkiln  -  https://bitkiln.itch.io
Retro game assets, fired in the kiln.

2 animated low-poly PS1-style sea horror enemies from PSX SEA HORROR MONSTERS, free for personal and
commercial projects (see LICENSE.txt): the same quality, the same formats and the same Godot 4 enemy script as
the full pack. The full pack: https://bitkiln.itch.io/psx-sea-horror-monsters

FOLDERS
  Models/GLB/<monster>/<monster>_<skin>.glb   mesh + armature + every clip, that skin's texture inside
  Models/FBX/<monster>/<monster>.fbx          the same as FBX (first skin embedded)
  Textures/<monster>/<monster>_<skin>.png     the skin textures
  Catalog/                                    catalog (CSV, JSON, Markdown) and contact sheets
  Godot/                                      Godot 4.3 project: ready enemy scenes, showcase, hunt demo

THE FULL PACK
  PSX Sea Horror Monsters has 13 monsters, each with every clip and 2 skins, GLB + FBX and the full Godot demo
  with all of them, for $2.99 (a fixed price): https://bitkiln.itch.io/psx-sea-horror-monsters. Thank you for
  trying the sampler!

CONTENTS (counted by the build)
- 2 monsters, 16 animations, 4 skins, 3,896 triangles in total
- every monster: one skinned mesh, one armature, a 256 x 256 texture per skin

DROWNED FISHERMAN (drowned): humanoid, 1.78 m, 1,690 triangles, 29 bones
  Bloated drowned fisherman in a torn oilskin coat and sou'wester, dragging one boot; clubs, grabs and bites,
  and retches up seawater.
  Skins: oilskin (yellow oilskin coat and sou'wester, oatmeal cable-knit sweater, black boots); deckhand (dark
    green oilskin, navy rib-knit sweater, dirty white boots)
  Clips: Idle 3.60 s loop, Walk 2.00 s loop, Run 0.90 s loop, Attack 1.30 s, Attack2 1.60 s, Hit 0.60 s, Death
    2.40 s, Retch 2.80 s
  Game data: walk 0.33 m/s, run 1.69 m/s; Attack range 1.3 m, the blow lands at 0.56 s; Attack2 range 0.95 m,
    lands at 0.84 s; height 1.78 m, body radius 0.34 m

GIANT CRAB (crab): beast, 0.71 m, 2,206 triangles, 38 bones
  Huge barnacle-crusted harbor crab with a spiky shell, glowing eyes on stalks and one oversized crusher claw:
  scuttles forward, pinches, slams the crusher down and rears up with both claws raised.
  Skins: rust (red-brown shell crusted with gray-white barnacles, black-tipped claws, ember eyes); bone (pale
    abyssal white shell with pale crusted barnacles, dark violet claw tips, cyan eyes)
  Clips: Idle 4.00 s loop, Walk 0.80 s loop, Run 0.40 s loop, Attack 1.30 s, Attack2 1.60 s, Hit 0.50 s, Death
    2.40 s, Threat 2.40 s
  Game data: walk 0.62 m/s, run 2.55 m/s; Attack range 1.5 m, the blow lands at 0.56 s; Attack2 range 1.5 m,
    lands at 0.66 s; height 0.71 m, body radius 0.6 m

UNITS, ORIENTATION, RIG
- 1 unit = 1 meter, real-world sizes. +Y is up and every monster faces +Z (the glTF convention); the origin
  is on the floor under the body (the Tentacle Lurker: on the floor at the wall face, facing out of the wall).
- Rigid skinning like the original console: every vertex follows exactly one bone, joints are hidden with
  overlapping parts. Nothing to apply or fix: rotation 0 and scale 1.
- The walking humanoids use the common humanoid bone names (Hips, Spine, Chest, Neck, Head, LeftUpperArm,
  LeftLowerArm, LeftHand, LeftUpperLeg, LeftLowerLeg, LeftFoot and the Right ones) plus extra bones for
  jaws, coats, hair, hoses or chains; the beasts have their own skeletons.

CLIPS (the names are the same on every monster, so one controller drives all of them)
- Idle, Walk and Run loop seamlessly; Attack, Hit, Death and the extras play once. The one-shot clips start in
  the idle stance and end in it again (Death ends with the body lying still on the floor).
- Extras: Attack2 (a second attack), Threat (alert) and idle variations (Retch). Each monster's list is below.
- Every clip plays IN PLACE at 30 fps: move the body yourself at the walk / run speed below and the feet do
  not slide.

GAME DATA (per monster below and in Catalog/catalog.csv / catalog.json)
- walk / run: meters per second that match the in-place Walk and Run clips
- Attack range: start the attack when the target is this close; "lands at": seconds into the clip when the
  blow lands (deal the damage then)
- height and body radius: for a collision capsule; long or wide monsters (Giant Crab) reach farther than their
  capsule, the Godot scenes give them an extra body hitbox
- stationary: never moves; dormant / wake: waits hidden in the first frame of its wake clip
- floats: the clips themselves hold the body in the air, nothing to add

FORMATS
- GLB (glTF 2.0 binary): one file per skin, texture inside with a nearest sampler. Cut-out parts (hair,
  nets, kelp, fins, frayed edges) use alpha mask (cutoff 0.5) and are double-sided; glowing parts (eyes,
  lures, lanterns, bioluminescence) are a second material with the texture as emission.
- FBX (binary 7.4): the same mesh, armature and clips, the first skin embedded, scale 1 (meters).
- PNG: 256 x 256, RGBA where a monster has cut-out parts; nearest filtering.

GODOT 4 (4.3 or newer)
- The Godot project (Godot/ in this download): every monster as a ready enemy scene (collision, model, every
  clip, the MonsterBrain enemy script), a showcase and a playable hunt demo; see its README_GODOT.md.
- GLB only: drag a .glb into a scene; an AnimationPlayer holds every clip. Godot imports clips as
  play-once: set Idle, Walk and Run to loop (Advanced Import Settings > Animation > Loop Mode, or
  anim.loop_mode = Animation.LOOP_LINEAR). Keep the textures lossless (Embed as Uncompressed).

UNITY
- FBX download: Model tab Scale Factor 1; Rig tab Generic (the clips play as made). The walking humanoids
  can also be set to Humanoid for retargeting (if the avatar setup asks for a T-pose: Pose > Enforce T-Pose).
  Animation tab: tick Loop Time on Idle, Walk and Run.
- Textures: Filter Mode Point (no filter), Compression None. The FBX holds the first skin; put the other
  skin's PNG from Textures/ on the material. Cut-outs (hair, nets, kelp, fins): Alpha Clipping 0.5 and
  Render Face Both. Glowing parts (eyes, lures, lanterns): Emission with the same texture.
- GLB works too with a glTF importer (glTFast or UnityGLTF).

UNREAL ENGINE
- Import the FBX as a Skeletal Mesh with Import Animations on (or the GLB with the Interchange importer).
  If your project works in centimeters and the importer does not convert, import with scale 100.
- Textures: Filter Nearest, Compression UserInterface2D (RGBA), no mipmaps.

BLENDER
- File > Import > glTF 2.0 (.glb): mesh, armature, the texture (set the Image Texture nodes to Closest for
  the pixel look) and one action per clip. File > Import > FBX works too.
- FBX clip names: the takes in the FBX are named Idle, Walk, Run ... (the names Unity and Unreal show);
  Blender's FBX importer prefixes the armature: "Armature|Idle", "Armature|Walk" ...

TIPS
- Keep nearest filtering and lossless textures: 256 px textures smear with linear filtering or compression.
- Every clip is keyed every 1/30 s (linear between the keys). For the choppier motion of PS1 games, play
  them with step interpolation (each pose held until the next key, e.g. Nearest on Godot animation tracks)
  or sample them only 12-15 times a second in your own animation code.
- Same world, same scale: build the levels with the PSX Sea Horror Modular Kit, dress them with PSX Sea Horror
  Props and texture them with the PSX Sea Horror Texture Pack (https://bitkiln.itch.io).

LICENSE
See LICENSE.txt. Use the sampler in any personal or commercial project; do not resell or redistribute the
monsters themselves. Credit is appreciated but not required: "Art by bitkiln".

CONTACT
Questions, problems or monster requests: comment on the itch.io page (https://bitkiln.itch.io) or write to
@bitkiln_assets on X. Thank you for supporting a small creator!
