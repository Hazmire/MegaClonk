# Megaclonk: Fusion weapons, powerups and ultimates

These are the sounds for the Fusion weapons, the Stopwatch and Magnet powerups, and the three ultimates. They go with the main Megaclonk audio pack. Everything is synthesised from code and original, with no samples and nothing to license.

- `manifest.json` has one entry per **event**, in the same format as the main pack's manifest. Each entry gives:
  - the event's files, bus, loop flag, positional flag and channel count;
  - when it plays;
  - suggested `cooldown`, `max_voices`, `pitch_var` and `priority`;
  - the measured duration, peak and RMS.
- `audio/` holds 64 WAV files (44.1 kHz, 16-bit, mono) in 38 events.
- `reference/premixed_fusion_weapons/` holds 252 weapon sounds with each Fusion already mixed in. They're for listening only. The game layers `fusion.*` at runtime.

**The WAVs are finished.** Import them exactly as they are, with no resampling, gain or "dark pass".

## Folders

| Folder | Files | Bus | Positional | What |
|---|---|---|---|---|
| `audio/fusion/` | 42 | SFX | yes | For each of the six Fusions: attack ×3, hit ×3 and a loop |
| `audio/imbue_combo/` | 6 | UI | no | The forging moment for each Fusion. These replace the old `imbue_combo_*` files. |
| `audio/powers/` | 5 | SFX | no | Stopwatch: activate, loop, end. Magnet: activate, rush. |
| `audio/ultimates/` | 11 | SFX | no | Berserker, Cataclysm and Ghost form: activate, loop, end and dashes |

## Fusions

| Fusion | Gems | Combo | Events |
|---|---|---|---|
| Steamforged | fire + ice | Thermal Shock | `fusion.steamforged.attack / .hit / .loop`, `imbue.imbue_combo_thermal_shock` |
| Plasma | electricity + fire | Overcharge | `fusion.plasma.*`, `imbue.imbue_combo_overcharge` |
| Aurora | electricity + ice | Cryoshock | `fusion.aurora.*`, `imbue.imbue_combo_cryoshock` |
| Livewire | corrosive + electricity | Toxic Conduction | `fusion.livewire.*`, `imbue.imbue_combo_toxic_conduction` |
| Pyrebile | corrosive + fire | Caustic Combustion | `fusion.pyrebile.*`, `imbue.imbue_combo_caustic_combustion` |
| Rimerot | corrosive + ice | Blightfrost | `fusion.rimerot.*`, `imbue.imbue_combo_blightfrost` |

- **Replace, don't stack.** On a Fusion weapon, `fusion.<id>.attack`, `.hit` and `.loop` play wherever `element.*` plays today. They **replace** both single-gem layers, never add to them. Weapons with one gem, or two gems that aren't a combo, keep `element.*` as before.
- **Each Fusion is its own sound,** following what the Fusion does on a hit. Steamforged's ice shell snaps shut, then puffs into steam. Plasma's crackle line detonates. Aurora's crystals zap, then shatter. Livewire's arc fizzes in a puddle. Pyrebile's bile catches. Rimerot's black ice crunches upward.
- **Levels.** The layers are short (attack 0.28 s, hit 0.45 s), soft-fronted and filtered, so they hold up when they repeat constantly. They sit about 4 dB under the single-gem layers on their loudest moment. Don't re-gain them.
- **The forging moment.** `imbue.imbue_combo_<combo>` is 3.4 s long, and the two gems fuse at **0.85 s** (`fuse_moment_s` in the manifest). Sync the forge's collision, flash and shatter to that point.

## Powerups

- **Stopwatch:**
  - `powerup.stopwatch_activate` as time stops.
  - `powerup.stopwatch_loop` while frozen. It's seamless, 4 s long, and should be stopped on release. `silence_loops()` should also stop it on pause and level-up.
  - `powerup.stopwatch_end` on release.
- **Magnet:** `powerup.magnet_activate` on pickup, then `powerup.magnet_rush` about 0.5 s later while the gems fly in. The normal gem pickup sound still plays as each gem lands.

## Ultimates

All three open on the same 0.3 s swell into a low bell, a boom and a choir, so players learn the sound of an ultimate.

- **Berserker:** `ult.berserker` on activation, then `ult.berserker_loop` about 1.5 s later for as long as it lasts, then `ult.berserker_end`. There's no voice: the protagonist is silent. The rage comes from a pick scrape into a crushing guitar chord, feedback that climbs into a howl, and the belt radio blowing out.
- **Cataclysm:** `ult.cataclysm_activate` on the button press, then `weapon.ult_cataclysm` (the blast, unchanged) when it detonates, about 1 s later.
- **Ghost form:**
  - `ult.ghost_form` on activation, then `ult.ghost_loop` about 1.5 s later.
  - `ult.ghost_dash` (3 variations) for each dash or burst of speed, in place of footsteps.
  - `ult.ghost_end` when it ends.

## Checked

- Every loop was checked for a clean seam. The end-to-start jump is under a tenth of the file's typical sample step.
- Levels were measured, and are listed in the manifest.

Nothing has been heard by a person yet, so judge it by ear in the game.
